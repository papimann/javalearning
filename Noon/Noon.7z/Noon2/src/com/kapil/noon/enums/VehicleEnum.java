package com.kapil.noon.enums;

public enum VehicleEnum {

	Car, MotorCycle, Bus;
}
