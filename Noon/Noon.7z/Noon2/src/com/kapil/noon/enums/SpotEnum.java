package com.kapil.noon.enums;

public enum SpotEnum {

	MotorCycleSpot, CompactSpot, LargeSpot;
}
